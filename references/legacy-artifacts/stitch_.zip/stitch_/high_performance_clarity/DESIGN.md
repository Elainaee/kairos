---
name: High-Performance Clarity
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3d4a3e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6d7b6d'
  outline-variant: '#bccabb'
  surface-tint: '#006d36'
  primary: '#006d36'
  on-primary: '#ffffff'
  primary-container: '#4ade80'
  on-primary-container: '#005e2d'
  inverse-primary: '#4de082'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#674bb5'
  on-tertiary: '#ffffff'
  tertiary-container: '#ccbaff'
  on-tertiary-container: '#593ca7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6dfe9c'
  primary-fixed-dim: '#4de082'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005227'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#e8ddff'
  tertiary-fixed-dim: '#cebdff'
  on-tertiary-fixed: '#21005e'
  on-tertiary-fixed-variant: '#4f319c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style

This design system centers on the concept of cognitive ease and momentum. It is built for a productivity environment where the interface stays out of the way of the user’s focus while providing gentle, encouraging cues for task completion and habit formation. 

The aesthetic is **Modern Corporate**, blending high-utility layouts with soft, organic color hits. The goal is to evoke a sense of organized calm—reducing the anxiety often associated with long "to-do" lists through generous whitespace, a structured hierarchy, and a refreshing, nature-inspired palette. It avoids the coldness of pure minimalism by using soft lavender accents and vibrant mint highlights to celebrate user progress.

## Colors

The color palette is strategically weighted to balance professional authority with motivational energy.

*   **Primary (Mint Green):** Reserved for "Success" states, habit completion, and primary action buttons. It serves as a visual reward.
*   **Secondary (Deep Slate):** Used for typography, iconography, and structural borders. It provides the grounding force and ensures high legibility.
*   **Tertiary (Soft Lavender):** Used for task categorization, focus modes, and secondary highlights. It offers a sophisticated contrast to the mint green without appearing aggressive.
*   **Neutral (Slate Grays):** A range of cool grays (from #F8FAFC to #94A3B8) is used for backgrounds and subtle card strokes to maintain a clean, breathable interface.

## Typography

This design system utilizes **Inter** across all levels to ensure maximum readability and a technical, yet approachable, feel. 

Headlines use a bold weight with slightly negative letter-spacing to create a "dense" and authoritative look that draws the eye to section starts. Body text is optimized for long-form reading in habit descriptions or calendar notes, utilizing a generous line-height to prevent visual crowding. Labels use a medium-to-bold weight and occasionally an uppercase transform to distinguish metadata from content.

## Layout & Spacing

The layout is built on a **8px square grid**, ensuring mathematical harmony between all elements. 

*   **Grid System:** On mobile, a fluid single-column layout is used with 20px side margins. On desktop, a 12-column fluid grid is employed with a maximum container width of 1280px.
*   **Spacing Rhythm:** Vertical spacing between cards follows a 16px (md) or 24px (lg) increment to maintain clear separation of daily tasks.
*   **Safe Areas:** Content should never bleed into the 20px edge margin on mobile to ensure the "Clarity" objective is met, giving the UI room to "breathe."

## Elevation & Depth

Hierarchy is established through **Ambient Shadows** and **Tonal Layering** rather than heavy lines.

1.  **Background (Level 0):** The base layer uses the soft Neutral Gray (#F8FAFC).
2.  **Surface (Level 1):** Primary content cards use a pure white (#FFFFFF) background with a very subtle 1px border (#E2E8F0) and a soft, diffused shadow (Y: 4px, Blur: 12px, Opacity: 4% Black).
3.  **Floating (Level 2):** Modals, dropdowns, and active navigation elements use a more pronounced shadow (Y: 8px, Blur: 24px, Opacity: 8% Black) to clearly sit above the surface.

This approach creates a tactile, layered feel that mimics physical paper without the clutter of high-contrast dividers.

## Shapes

The shape language is friendly and modern. The system uses a **Rounded (0.5rem base)** logic to soften the interface and make it feel more encouraging.

*   **Standard Cards:** Always use a 16px (1rem) corner radius.
*   **Buttons:** Use a 12px corner radius for a "squircle" look that feels premium.
*   **Progress Indicators:** Habit tracking rings and toggle switches use full-pill rounding (caps) to differentiate them from static content containers.

## Components

### Buttons
*   **Primary:** Mint Green background with Deep Slate text for high contrast. High-gloss hover states.
*   **Secondary:** Ghost style with a Deep Slate border and Lavender text for subtle secondary actions.

### Progress Rings
*   **Habit Tracker:** A circular SVG stroke using the Primary Mint color for the completed percentage and a light gray for the remaining track. The center often contains a "Check" icon or a percentage number.

### Cards
*   **Task Card:** White surface, 16px rounded corners. Contains a Lavender vertical accent bar on the left for "Work" tasks or Mint for "Personal."
*   **Calendar Day:** A square grid cell that highlights the current date with a Soft Lavender circular background.

### Inputs & Selection
*   **Checkboxes:** Large, rounded squares (8px radius) that transform into a filled Mint Green state with a white checkmark when active.
*   **Navigation:** An icon-based bottom bar (mobile) or side rail (desktop) using Deep Slate icons that shift to Lavender with a subtle background glow when active.