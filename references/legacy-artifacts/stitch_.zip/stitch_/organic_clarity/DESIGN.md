---
name: Organic Clarity
colors:
  surface: '#fbf9f2'
  surface-dim: '#dcdad3'
  surface-bright: '#fbf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4ed'
  surface-container: '#f0eee7'
  surface-container-high: '#eae8e1'
  surface-container-highest: '#e4e2dc'
  on-surface: '#1b1c18'
  on-surface-variant: '#57423c'
  inverse-surface: '#30312c'
  inverse-on-surface: '#f3f1ea'
  outline: '#8a726a'
  outline-variant: '#ddc0b7'
  surface-tint: '#a1401b'
  primary: '#9e3d19'
  on-primary: '#ffffff'
  primary-container: '#be552f'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59d'
  secondary: '#615f50'
  on-secondary: '#ffffff'
  secondary-container: '#e8e3d0'
  on-secondary-container: '#676556'
  tertiary: '#00666f'
  on-tertiary: '#ffffff'
  tertiary-container: '#00818c'
  on-tertiary-container: '#f6feff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59d'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#812904'
  secondary-fixed: '#e8e3d0'
  secondary-fixed-dim: '#cbc7b5'
  on-secondary-fixed: '#1d1c11'
  on-secondary-fixed-variant: '#494739'
  tertiary-fixed: '#8af2ff'
  tertiary-fixed-dim: '#6bd6e3'
  on-tertiary-fixed: '#001f23'
  on-tertiary-fixed-variant: '#004f56'
  background: '#fbf9f2'
  on-background: '#1b1c18'
  surface-variant: '#e4e2dc'
  surface-muted: '#EBE6D6'
  ink-bold: '#3D3B2E'
  accent-terracotta: '#D1633C'
  canvas-bone: '#F9F7F0'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  title-md:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin: 32px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is built on the philosophy of "Warm Minimalist Focus." For a calendar application, the goal is to reduce cognitive load while maintaining a human, tactile feel. This system eschews cold, sterile whites in favor of a sophisticated, parchment-like palette that feels archival and permanent.

The aesthetic direction is **Modern Minimalism** with a **Tactile** twist. It prioritizes generous negative space, high-quality geometric typography, and subtle tonal layering rather than aggressive shadows. The intent is to evoke a sense of calm productivity—moving the user from "busyness" to "intentionality."

## Colors
The palette is grounded in earthy, organic tones. The primary color, a terracotta orange, is used sparingly for call-to-actions, active states, and critical time-sensitive indicators. The deep charcoal serves as the primary "ink" color, providing high-contrast legibility against the bone-colored backgrounds.

- **Canvas (Primary Background):** Use #F9F7F0 for the main application background.
- **Surface (Secondary/Muted):** Use #EBE6D6 for sidebar containers, card backgrounds, or "past" events in the calendar grid.
- **Ink:** Use #3D3B2E for all primary text. Never use pure black.
- **Action:** #D1633C is reserved for primary buttons, active date selections, and progress indicators.

## Typography
This design system utilizes **Outfit** exclusively to maintain a cohesive, geometric, and modern appearance. The typeface's open counters ensure legibility even at small sizes within dense calendar grids.

For display and headlines, use tighter letter spacing and heavier weights to create a strong visual anchor. Body text should maintain a generous line height (1.6) to improve readability in long-form event descriptions or notes. Labels use a slightly increased letter spacing and uppercase styling to distinguish metadata from content.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. On desktop, the main calendar view behaves as a fluid grid, while sidebars for navigation and event details remain at fixed widths (280px and 360px respectively).

Spacing is governed by an 8px base unit. 
- **Desktop:** 32px outer margins with 16px gutters between grid cells.
- **Tablet:** 24px outer margins.
- **Mobile:** 16px outer margins. The calendar grid should reflow from a 7-day view to a 3-day or single-day view depending on horizontal space.

## Elevation & Depth
Elevation is achieved through **Tonal Layering** and **Hairline Outlines** rather than traditional drop shadows. This preserves the "Clarity" aspect of the app by avoiding visual clutter.

- **Level 0 (Canvas):** #F9F7F0. The base layer.
- **Level 1 (Containers/Cards):** Use #EBE6D6 with a 1px solid border of #3D3B2E at 10% opacity.
- **Level 2 (Popovers/Modals):** Use #F9F7F0 with a 1px solid border of #3D3B2E at 20% opacity and a very soft, high-diffusion shadow (0px 12px 32px rgba(61, 59, 46, 0.08)).
- **Interactivity:** Elements being dragged should scale slightly (1.02x) and receive a more pronounced shadow to indicate they are "lifted" from the grid.

## Shapes
The shape language is consistently **Rounded**. This softens the rigid nature of a calendar's grid-heavy layout. 

- **Primary Buttons & Inputs:** 0.5rem (8px) corner radius.
- **Event Chips:** 0.5rem (8px) corner radius to ensure they feel like distinct "objects" within the grid.
- **Modals & Side Panels:** 1rem (16px) corner radius for a more prominent, architectural feel.

## Components
Consistent component styling ensures the design system remains predictable and intuitive.

- **Buttons:** 
  - *Primary:* Terracotta (#D1633C) background with Bone (#F9F7F0) text. No shadow; use a slight darken on hover.
  - *Secondary:* Transparent background with a 1px border of #3D3B2E.
- **Calendar Chips:** Should use #EBE6D6 as the base. If an event is categorized, use a small 4px vertical accent bar on the left in the category color. 
- **Input Fields:** Use #F9F7F0 as the background with a 1px border of #EBE6D6. On focus, the border should transition to #D1633C.
- **Checkboxes/Radios:** Use the deep charcoal (#3D3B2E) for the active state to ensure high contrast against the bone background.
- **Day Headers:** Use `label-md` styling. The current day should be circled with the primary terracotta color.